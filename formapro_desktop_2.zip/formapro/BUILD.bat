@echo off
echo ============================================
echo    FormaPro - Creation du fichier .EXE
echo ============================================
echo.

echo [1/3] Installation de PyInstaller...
pip install pyinstaller --quiet

echo [2/3] Construction de l'application...
pyinstaller --noconfirm formapro.spec

echo [3/3] Termine !
echo.
echo ============================================
echo  Votre application est dans : dist\FormaPro.exe
echo  Double-cliquez dessus pour lancer !
echo ============================================
pause
