import sys
import os
import threading
import webbrowser
import time

# Fix paths for PyInstaller
if getattr(sys, 'frozen', False):
    base_dir = sys._MEIPASS
    # Set working directory to where the exe is
    os.chdir(os.path.dirname(sys.executable))
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

# Add base dir to path
sys.path.insert(0, base_dir)

# Set template and static folders
os.environ['FORMAPRO_BASE'] = base_dir

from flask import Flask, render_template, request, redirect, url_for, session, flash
from functools import wraps
import database as db

app = Flask(
    __name__,
    template_folder=os.path.join(base_dir, 'templates'),
    static_folder=os.path.join(base_dir, 'static')
)
app.secret_key = 'formapro_secret_key_mauritanie_2025'

# ── Auth helpers ──────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Veuillez vous connecter.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if session.get('role') not in roles:
                flash('Accès non autorisé.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated
    return decorator

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user = db.get_user_by_email(email)
        if user and user['password'] == db.hash_password(password) and user['actif']:
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['nom'] = f"{user['prenom']} {user['nom']}"
            session['email'] = user['email']
            flash(f"Bienvenue, {session['nom']} !", 'success')
            return redirect(url_for('dashboard'))
        flash('Email ou mot de passe incorrect.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Vous avez été déconnecté.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    if role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'formateur':
        return redirect(url_for('formateur_dashboard'))
    else:
        return redirect(url_for('etudiant_dashboard'))

# ADMIN
@app.route('/admin/dashboard')
@login_required
@role_required('admin')
def admin_dashboard():
    stats = db.get_dashboard_stats()
    sessions_list = db.get_all_sessions()[:5]
    return render_template('admin/dashboard.html', stats=stats, sessions=sessions_list)

@app.route('/admin/etudiants')
@login_required
@role_required('admin')
def admin_etudiants():
    return render_template('admin/etudiants.html', etudiants=db.get_all_users('etudiant'))

@app.route('/admin/etudiants/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_etudiant():
    if db.create_user(request.form['nom'], request.form['prenom'], request.form['email'], request.form['password'], 'etudiant', request.form.get('telephone','')):
        flash('Étudiant ajouté.', 'success')
    else:
        flash('Email déjà utilisé.', 'danger')
    return redirect(url_for('admin_etudiants'))

@app.route('/admin/etudiants/modifier/<int:uid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_modifier_etudiant(uid):
    db.update_user(uid, request.form['nom'], request.form['prenom'], request.form['email'], request.form.get('telephone',''), 1 if request.form.get('actif') else 0)
    flash('Étudiant modifié.', 'success')
    return redirect(url_for('admin_etudiants'))

@app.route('/admin/etudiants/supprimer/<int:uid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_etudiant(uid):
    db.delete_user(uid)
    flash('Étudiant supprimé.', 'success')
    return redirect(url_for('admin_etudiants'))

@app.route('/admin/formateurs')
@login_required
@role_required('admin')
def admin_formateurs():
    return render_template('admin/formateurs.html', formateurs=db.get_all_users('formateur'))

@app.route('/admin/formateurs/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_formateur():
    if db.create_user(request.form['nom'], request.form['prenom'], request.form['email'], request.form['password'], 'formateur', request.form.get('telephone','')):
        flash('Formateur ajouté.', 'success')
    else:
        flash('Email déjà utilisé.', 'danger')
    return redirect(url_for('admin_formateurs'))

@app.route('/admin/formateurs/modifier/<int:uid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_modifier_formateur(uid):
    db.update_user(uid, request.form['nom'], request.form['prenom'], request.form['email'], request.form.get('telephone',''), 1 if request.form.get('actif') else 0)
    flash('Formateur modifié.', 'success')
    return redirect(url_for('admin_formateurs'))

@app.route('/admin/formateurs/supprimer/<int:uid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_formateur(uid):
    db.delete_user(uid)
    flash('Formateur supprimé.', 'success')
    return redirect(url_for('admin_formateurs'))

@app.route('/admin/formations')
@login_required
@role_required('admin')
def admin_formations():
    return render_template('admin/formations.html', formations=db.get_all_formations())

@app.route('/admin/formations/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_formation():
    db.create_formation(request.form['titre'], request.form.get('description',''), int(request.form['duree_heures']), request.form.get('niveau','Débutant'), request.form.get('categorie',''), float(request.form.get('prix',0)))
    flash('Formation ajoutée.', 'success')
    return redirect(url_for('admin_formations'))

@app.route('/admin/formations/modifier/<int:fid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_modifier_formation(fid):
    db.update_formation(fid, request.form['titre'], request.form.get('description',''), int(request.form['duree_heures']), request.form.get('niveau','Débutant'), request.form.get('categorie',''), float(request.form.get('prix',0)), 1 if request.form.get('actif') else 0)
    flash('Formation modifiée.', 'success')
    return redirect(url_for('admin_formations'))

@app.route('/admin/formations/supprimer/<int:fid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_formation(fid):
    db.delete_formation(fid)
    flash('Formation supprimée.', 'success')
    return redirect(url_for('admin_formations'))

@app.route('/admin/sessions')
@login_required
@role_required('admin')
def admin_sessions():
    return render_template('admin/sessions.html', sessions=db.get_all_sessions(), formations=db.get_all_formations(True), formateurs=db.get_all_users('formateur'))

@app.route('/admin/sessions/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_session():
    db.create_session(int(request.form['formation_id']), int(request.form['formateur_id']), request.form['date_debut'], request.form['date_fin'], request.form.get('lieu',''), int(request.form.get('capacite_max',20)))
    flash('Session créée.', 'success')
    return redirect(url_for('admin_sessions'))

@app.route('/admin/sessions/modifier/<int:sid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_modifier_session(sid):
    db.update_session(sid, int(request.form['formation_id']), int(request.form['formateur_id']), request.form['date_debut'], request.form['date_fin'], request.form.get('lieu',''), int(request.form.get('capacite_max',20)), request.form.get('statut','planifiee'))
    flash('Session modifiée.', 'success')
    return redirect(url_for('admin_sessions'))

@app.route('/admin/sessions/supprimer/<int:sid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_session(sid):
    db.delete_session(sid)
    flash('Session supprimée.', 'success')
    return redirect(url_for('admin_sessions'))

@app.route('/admin/participations')
@login_required
@role_required('admin')
def admin_participations():
    return render_template('admin/participations.html', participations=db.get_all_participations(), etudiants=db.get_all_users('etudiant'), sessions=db.get_all_sessions())

@app.route('/admin/participations/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_participation():
    if db.inscrire_etudiant(int(request.form['etudiant_id']), int(request.form['session_id'])):
        flash('Inscription ajoutée.', 'success')
    else:
        flash('Déjà inscrit.', 'warning')
    return redirect(url_for('admin_participations'))

@app.route('/admin/participations/modifier/<int:pid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_modifier_participation(pid):
    note = request.form.get('note')
    db.update_participation(pid, request.form.get('statut','inscrit'), float(note) if note else None, request.form.get('commentaire',''))
    flash('Participation mise à jour.', 'success')
    return redirect(url_for('admin_participations'))

@app.route('/admin/participations/supprimer/<int:pid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_participation(pid):
    db.delete_participation(pid)
    flash('Supprimé.', 'success')
    return redirect(url_for('admin_participations'))

@app.route('/admin/certifications')
@login_required
@role_required('admin')
def admin_certifications():
    return render_template('admin/certifications.html', certifications=db.get_all_certifications(), etudiants=db.get_all_users('etudiant'), formations=db.get_all_formations(), sessions=db.get_all_sessions())

@app.route('/admin/certifications/ajouter', methods=['POST'])
@login_required
@role_required('admin')
def admin_ajouter_certification():
    numero = db.create_certification(int(request.form['etudiant_id']), int(request.form['formation_id']), int(request.form['session_id']), request.form.get('mention','Satisfaisant'), float(request.form.get('note_finale',0)))
    flash(f'Certification {numero} créée.', 'success')
    return redirect(url_for('admin_certifications'))

@app.route('/admin/certifications/supprimer/<int:cid>', methods=['POST'])
@login_required
@role_required('admin')
def admin_supprimer_certification(cid):
    db.delete_certification(cid)
    flash('Supprimé.', 'success')
    return redirect(url_for('admin_certifications'))

# ETUDIANT
@app.route('/etudiant/dashboard')
@login_required
@role_required('etudiant')
def etudiant_dashboard():
    uid = session['user_id']
    return render_template('etudiant/dashboard.html', sessions=db.get_sessions_by_etudiant(uid), certifications=db.get_certifications_by_etudiant(uid))

@app.route('/etudiant/sessions')
@login_required
@role_required('etudiant')
def etudiant_sessions():
    return render_template('etudiant/sessions.html', sessions=db.get_sessions_by_etudiant(session['user_id']))

@app.route('/etudiant/catalogue')
@login_required
@role_required('etudiant')
def etudiant_catalogue():
    return render_template('etudiant/catalogue.html', sessions=db.get_available_sessions(session['user_id']))

@app.route('/etudiant/inscrire/<int:session_id>', methods=['POST'])
@login_required
@role_required('etudiant')
def etudiant_inscrire(session_id):
    if db.inscrire_etudiant(session['user_id'], session_id):
        flash('Inscription réussie !', 'success')
    else:
        flash('Déjà inscrit.', 'warning')
    return redirect(url_for('etudiant_catalogue'))

@app.route('/etudiant/certifications')
@login_required
@role_required('etudiant')
def etudiant_certifications():
    return render_template('etudiant/certifications.html', certifications=db.get_certifications_by_etudiant(session['user_id']))

# FORMATEUR
@app.route('/formateur/dashboard')
@login_required
@role_required('formateur')
def formateur_dashboard():
    return render_template('formateur/dashboard.html', sessions=db.get_sessions_by_formateur(session['user_id']))

@app.route('/formateur/sessions')
@login_required
@role_required('formateur')
def formateur_sessions():
    return render_template('formateur/sessions.html', sessions=db.get_sessions_by_formateur(session['user_id']))

@app.route('/formateur/sessions/<int:sid>/etudiants')
@login_required
@role_required('formateur')
def formateur_etudiants(sid):
    return render_template('formateur/etudiants.html', session=db.get_session_by_id(sid), participants=db.get_participations_by_session(sid))

@app.route('/formateur/sessions/<int:sid>/noter/<int:pid>', methods=['POST'])
@login_required
@role_required('formateur')
def formateur_noter(sid, pid):
    note = request.form.get('note')
    db.update_participation(pid, request.form.get('statut','present'), float(note) if note else None, request.form.get('commentaire',''))
    flash('Note enregistrée.', 'success')
    return redirect(url_for('formateur_etudiants', sid=sid))

@app.route('/formateur/certifications')
@login_required
@role_required('formateur')
def formateur_certifications():
    uid = session['user_id']
    ses = db.get_sessions_by_formateur(uid)
    sids = [s['id'] for s in ses]
    certifs = [c for c in db.get_all_certifications() if c['session_id'] in sids]
    return render_template('formateur/certifications.html', certifications=certifs)

@app.route('/certificat/<numero>')
def certificat(numero):
    certif = db.get_certification_by_numero(numero)
    if not certif:
        flash('Certificat introuvable.', 'danger')
        return redirect(url_for('login'))
    return render_template('certificat.html', certif=certif)

@app.route('/certificat/imprimer/<int:cid>')
@login_required
def imprimer_certificat(cid):
    certif = db.get_certification_by_id(cid)
    if not certif:
        flash('Certificat introuvable.', 'danger')
        return redirect(url_for('dashboard'))
    return render_template('certificat.html', certif=certif, print_mode=True)


def open_browser():
    """Open browser after short delay"""
    time.sleep(1.5)
    webbrowser.open('http://localhost:5000')


if __name__ == '__main__':
    # Initialize DB
    db.init_db()
    # Open browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()
    # Run Flask
    app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)
